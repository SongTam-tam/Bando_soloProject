import styled from 'styled-components';

export const ContentStyleVI = styled.section`
    width: 100%;
    height: 2000px;
`;
