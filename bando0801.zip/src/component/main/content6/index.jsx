import React from 'react';
import { ContentStyleVI } from './style';

const Content6 = () => {
    return <ContentStyleVI></ContentStyleVI>;
};

export default Content6;
