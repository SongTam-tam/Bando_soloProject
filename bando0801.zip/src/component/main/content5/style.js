import styled from 'styled-components';

export const ContentStyleV = styled.section`
    width: 100%;
    background-image: url(./images/content5_bg.png);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: 0 0;
    height: 1000px;
    position: relative;
    overflow: hidden;
    span {
        color: #000;
    }
    strong {
        color: #000;
    }
    /* padding-left: 160px; */
    .content5_pic {
        position: absolute;
        top: 258px;
        right: 154px;
        width: 458px;
        height: 258px;
        transition: none;

        img {
            width: 100%;
        }
    }
    .inner {
        display: flex;

        h2 {
            margin-left: 160px;
            margin-top: 231px;
            font-size: 150px;
            font-weight: 900;
            color: #000;
            white-space: pre-line;
            line-height: 1.3;
        }

        .textItem {
            position: absolute;
            top: 674px;
            right: 154px;
            strong {
                display: block;
                font-size: 32px;
                font-weight: 600;
                /* color: #000; */
                white-space: pre-line;
                line-height: 1.3;
                margin-bottom: 44px;
                text-align: right;
            }
            span {
                display: block;
                font-size: 20px;
                font-weight: 600;
                /* color: #000; */
            }
        }
    }
`;
