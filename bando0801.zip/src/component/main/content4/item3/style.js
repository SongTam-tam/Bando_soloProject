import styled from 'styled-components';
export const PicItemThird = styled.div`
    width: 100%;
    margin-top: 350px;
    span {
        display: block;
        margin-top: 15px;
        font-size: 15px;
        font-weight: 500;
        color: #333;
    }
    .contentBox {
        display: flex;
        width: 100%;
        justify-content: right;
        gap: 19px;
    }
`;
