import Content1 from '../../component/main/content1/';
import Content2 from '../../component/main/content2';
import Content3 from '../../component/main/content3';
import Content4 from '../../component/main/content4';
import Content5 from '../../component/main/content5';
import Content6 from '../../component/main/content6';
import Visual from '../../component/main/visual/VIsual';
import { MainStyle } from './style';

const Main = () => {
    return (
        <MainStyle>
            <Visual />
            <Content1 />
            <Content2 />
            <Content3 />
            <Content4 />
            <Content5 />
            <Content6 />
        </MainStyle>
    );
};

export default Main;
