import styled from 'styled-components';

export const MainStyle = styled.main`
    width: 100%;
    position: relative;
`;
